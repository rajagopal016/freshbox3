package com.freshbox.freshbox.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.freshbox.freshbox.dao.ProductDAO;
import com.freshbox.freshbox.model.Cuisine;
import com.freshbox.freshbox.model.Product;
@Controller
public class IndexController {
	
	@Autowired
	ProductDAO productdao;
	@GetMapping(value={"/home","/", "/index"})
	public String home(Model model) {
		List<Cuisine> cuisine = productdao.getCuisines();
		model.addAttribute("cuisines", cuisine);
		List<Product> products = productdao.getProducts();
		model.addAttribute("products", products);
		return "index";
	}
	
	@GetMapping("/userlogin")
	public String userlogin(Model model) {
		return "userlogin2";
	}
	
	@GetMapping("/userreg")
	public String userreg(Model model) {
		return "userregistration";
	}

	
	
	
}
