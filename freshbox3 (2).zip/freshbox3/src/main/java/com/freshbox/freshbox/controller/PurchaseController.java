package com.freshbox.freshbox.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.freshbox.freshbox.dao.CuisineRepository;
import com.freshbox.freshbox.dao.ProductDAO;
import com.freshbox.freshbox.model.Cuisine;
import com.freshbox.freshbox.model.Product;

@Controller
public class PurchaseController {
	@Autowired
	ProductDAO productdao;
	CuisineRepository cuisineRepository;
	@RequestMapping("/sideBarFilter/{cuisinename}")
	public String addProduct(@PathVariable("cuisinename") String cuisinename, Model model) {
		
		List<Product> products = productdao.listProductByCuisine(cuisinename);
		List<Cuisine> cuisines = productdao.getCuisines();
		model.addAttribute("products", products);
		model.addAttribute("cuisines", cuisines);
		return "index";
		
	}

}
