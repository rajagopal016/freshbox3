package com.freshbox.freshbox;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FreshboxApplicationTests {

	@Test
	void contextLoads() {
	}

}
